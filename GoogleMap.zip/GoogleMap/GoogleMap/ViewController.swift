//
//  ViewController.swift
//  GoogleMap
//
//  Created by Ya Fang Cheng on 2016/11/3.
//  Copyright © 2016年 Ya Fang Cheng. All rights reserved.
//

import UIKit
import CoreLocation
import GoogleMaps

class ViewController: UIViewController, CLLocationManagerDelegate, GMSMapViewDelegate {
    

    
    var myLocation: CLLocation?
    
    @IBOutlet weak var mapView: GMSMapView!
    
     @IBOutlet weak var addressTextField: UITextField!
    var locationManager = CLLocationManager()
    var didFindMyLocation = false
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        // let camera: GMSCameraPosition = GMSCameraPosition.cameraWithLatitude(25.04, longitude: 121.5097553, zoom: 14.0)
        
        
        let camera: GMSCameraPosition = GMSCameraPosition.camera(withLatitude: 25.04, longitude: 121.5097553, zoom: 14.0)
        
        mapView.delegate = self
        mapView.camera = camera
        //        mapView.myLocationEnabled = true
        
        
        
    }
    
    func mapView(_ mapView: GMSMapView, didChange position: GMSCameraPosition) {
        print("拿到中心點位置？\(position.target.latitude) \(position.target.longitude)")
        // cirlce.position = position.target
        
        
        let longitude :CLLocationDegrees = position.target.longitude
        let latitude :CLLocationDegrees = position.target.latitude
        
        let location = CLLocation(latitude: latitude, longitude: longitude) //changed!!!
        
        
        CLGeocoder().reverseGeocodeLocation(location, completionHandler: {(placemarks, error) -> Void in
            
            
            if error != nil {
                print("Reverse geocoder failed with error" + error!.localizedDescription)
                return
            }
            
            if placemarks!.count > 0 {
                let pm = placemarks![0]
                //print("轉成地址是\(pm.locality)")
                if pm.postalCode != nil && pm.subAdministrativeArea != nil && pm.locality != nil && pm.thoroughfare != nil && pm.subThoroughfare != nil {
                    
                    print("轉成地址\(pm.postalCode!)\(pm.subAdministrativeArea!)\(pm.locality!)\(pm.thoroughfare!)\(pm.subThoroughfare!)號")
                    self.addressTextField.text = "\(pm.postalCode!)\(pm.subAdministrativeArea!)\(pm.locality!)\(pm.thoroughfare!)\(pm.subThoroughfare!)號"
                    
                }else{
                    print("有缺資訊")
                }
                
            }
            else {
                print("Problem with the data received from geocoder")
            }
        })
        
    }


}

